# Lab One‑Stop Portal (Static Site)

This is a static, single‑file version of the Lab Portal. You can deploy it in under a minute.

## Files
- `lab_portal.html` — the portal webpage (all client‑side).
- `README.md` — this file.

## Quick Deploy Options

### Option A: Netlify Drop (easiest)
1. Go to https://app.netlify.com/drop
2. Drag and drop **`lab_portal.html`** (or this entire ZIP).  
3. Netlify will give you a public URL immediately (e.g., `https://your-site-name.netlify.app`).  
4. Share the link with your lab. Done!

### Option B: GitHub + Netlify (for updates & versioning)
1. Create a new GitHub repo (e.g., `lab-portal-static`).
2. Commit `lab_portal.html` and push.
3. On https://app.netlify.com , **New site from Git**, connect your repo, and deploy.
4. Each time you update `lab_portal.html`, push to GitHub; Netlify will auto‑deploy.

### Option C: GitHub Pages
1. Create a new GitHub repo, add `lab_portal.html` at the root.
2. On repo Settings → **Pages** → Source: `main` (root).
3. Open the provided Pages URL.

### Option D: Any static hosting
Upload `lab_portal.html` to any static host (S3 + CloudFront, GCP Storage, Azure Storage, nginx, etc.).

## How to Update Links
Open `lab_portal.html`, find the `DEFAULT_LINKS` array near the bottom:
```js
const DEFAULT_LINKS = [
  { id: "benchling", title: "Benchling", url: "https://www.benchling.com", category: "Sequences & Cloning", tags: ["DNA","plasmid","PCR"], notes: "质粒图、引物、序列注释" },
  ...
];
```
Add/edit entries, save, and redeploy (re‑upload to Netlify Drop, or push to GitHub).

## Data & Privacy
- The app is 100% client‑side. No backend, no tracking.
- Favorites and custom links are saved **only** in each user's browser (localStorage).
- If you want shared, centralized links for the whole lab by default, edit the `DEFAULT_LINKS` in this file and redeploy.

## Custom Domain (optional)
- On Netlify: Site settings → Domain management → Add custom domain (e.g., `lab.your‑lab.org`).
